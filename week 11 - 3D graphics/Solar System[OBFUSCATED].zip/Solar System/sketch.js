
function setup() {
    createCanvas(900, 600, WEBGL);
    angleMode(DEGREES);
    //remove wireframes
    noStroke();
    rectMode(CENTER);
    camera(0,-400,height,0,-20,0,0,1,0);
}
//code to draw the sun
function drawSun() {
    sphere(75);
    pointLight(255, 255, 255, 0, 0, 0);
    pointLight(255, 255, 255, 0, 0, 0);
}
//code to draw the earth
function drawEarth() {
    ambientMaterial(255, 255, 255);
    sphere(50);
}

function draw() {
    //used to reset frames to simulate animation
    background(155);
    
    push();
    drawSun();
    //rotate
    rotateY(-frameCount);
        push();
        translate(260, 0, 0);
        rotateY(frameCount);
        drawEarth();
        pop();
    pop();

}
